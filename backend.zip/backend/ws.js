const {Server} = require('socket.io')
const socketMiddleware = require('./middleware/socket-middleware')
const chatService = require('./service/chatService')
const userService = require('./service/userService')

module.exports = function ws(server, store) {
    const io = new Server(server, {
        cors:{
            origin: "http://localhost:3000"
        }
    })
    socketMiddleware(io)

    io.on('error', err => console.log(err))

    io.on('connection', async (socket) => {

        const user = await userService.setStatusActivity(true, socket.email, socket.id)
        socket.id = user._id
        // socket.join(socket.id)

        socket.emit('mess', socket.id)

        console.log(`User: ${socket.username} has been connected ID: ${socket.id}`);

        socket.on('disconnect', async () => {
            await userService.setStatusActivity(false, socket.email)
            console.log(`User: ${socket.username}, ID: ${socket.id}, has been disconnect`);
        })
        
        socket.on("private room", async (frinedEmail)=>{
            const frinedId = await chatService.getUserId(frinedEmail)
            if(!frinedId){
                return console.log(`User: ${frinedEmail} not found`);
            }
            const room = await chatService.getRoomWithUser(frinedId)
            if(room){
                return console.log(`User: ${socket.username}, ID: ${socket.id} have room with ${frinedEmail}`);
            }
            const createRoom = await chatService.createPrivateRoom(socket.email, frinedEmail)
            if(createRoom){
                console.log(socket.rooms);
                return console.log(`User: ${socket.username}, ID: ${socket.id}, was create a room with ${frinedEmail}`);
            }
        })
        socket.on("create room", () =>{})
        socket.on("delete room", () =>{})
        socket.on("add mess", (to, mess) =>{

        })
        socket.on("delete mess", () =>{})
        socket.on("get rooms", async()=>{
            const rooms = await chatService.getRooms(socket.id);
            socket.emit('rooms', rooms)
        })
    })
    
}