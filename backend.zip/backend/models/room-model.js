const {Schema, model} = require('mongoose')

const RoomSchema = new Schema({
    admin: {type: Schema.Types.ObjectId, ref: 'User'},
    users: [{
        userId:{type: Schema.Types.ObjectId, ref: 'User'},
    }],
    chat: [{
        message:{
            createAt: {type: Date, default: Date.now},
            from: {type: Schema.Types.ObjectId, ref: 'User'},
            text: {type: String}
        }
    }]
    },
    {
        timestamps: true,
        collection: 'rooms'
    }
)

module.exports = model('Room', RoomSchema)