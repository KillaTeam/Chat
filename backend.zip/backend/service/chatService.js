
const roomModel = require("../models/room-model")
const userModel = require("../models/user-model")

class ChatService {
    async getUserId(email){
        try {
            const user = await userModel.findOne({email})
            if(!user){
                return undefined
            }
            return user._id
        } catch (err) {
            console.log(err);
        }
    }
    async createPrivateRoom (email, to) {
        try {
            const admin = await userModel.findOne({email})
            if (!admin){
                return "invalid user"
            }
            const friend = await userModel.findOne({email: to})
            if (!friend){
                return "invalid friend"
            }
            const room = await roomModel.create({users: [{userId: admin.id}, {userId: friend.id}]})
            return true
        } catch (err) {
            console.log(err);
        }
    }
    async getRoomWithUser(id, email){
        const friendId = this.getUserId(email)
        const room = await roomModel.findOne({users: {$elemMatch: {userId: id}}})
        console.log(room);
        if(!room) {
            return undefined;
        }
        return room

    }
    async getRooms (id) {
        try {
            const rooms = await roomModel.find({users: {$elemMatch: {userId: id}}})
            if(rooms.length <= 0) {
                return undefined;
            }
            return rooms
        } catch (err) {
            console.log(err);
        }
    }
    async createGroupRoom(email, users){
        try {
            
        } catch (err) {
            console.log(err);
        }
    }
}
module.exports = new ChatService()